__webpack_public_path__ = window.__assets_js_src
