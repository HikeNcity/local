---
date: 2018-07-06T01:00:00+06:00
lastmod: 2018-07-20T20:00:00+06:00
title: "Search: Fuse.js"
authors: ["muniftanjim"]
categories:
  - features
tags:
  - search
  - fuse.js
slug: search-fuse-js
toc: true
---

## Configure Fuse.js Search Client

Select Fuse.js as the search client in your `config.toml` file:

```toml
[params.search]
client = "fuse"
```
